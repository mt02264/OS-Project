#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <mqueue.h>

#include "common.h"


int main(int argc, char **argv)
{
    mqd_t mq;
    char buffer[MAX_SIZE];

    /* open the mail queue */
    mq = mq_open(QUEUE_NAME, O_WRONLY);
    CHECK((mqd_t)-1 != mq);

	
	int randomNumber[1000];		//initialize random number array
	for (int i=0; i<1000; i++) {
		randomNumber[i] = rand();
	} 

	FILE *filename = fopen("producer.txt", "w");		//open the file

	if (filename == NULL)
	{
		printf("File could nto be opened\n");
		exit(1);		//exits the program
	}	

int countLoop = 0;

    do {

        fflush(stdout);

        memset(buffer, 0, MAX_SIZE);

	sprintf(buffer, "%d", randomNumber[countLoop]);	//integers converted to string
	//writes string(integers) in buffer

	fprintf(filename, "%d. %s\n", countLoop+1, buffer); 	//writes in the file the value of buffer

        CHECK(0 <= mq_send(mq, buffer, MAX_SIZE, 0));		//send the message
	
countLoop++; 	//counter increment

    } while (countLoop < 1000);

	fclose(filename);	//close the file

    /* cleanup */
    CHECK((mqd_t)-1 != mq_close(mq));

    return 0;
}
