#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <mqueue.h>

#include "common.h"

int main(int argc, char **argv)
{
    mqd_t mq;
    struct mq_attr attr;
    char buffer[MAX_SIZE + 1];
    int must_stop = 0;

    /* initialize the queue attributes */
    attr.mq_flags = 0;
    attr.mq_maxmsg = 10;
    attr.mq_msgsize = MAX_SIZE;
    attr.mq_curmsgs = 0;

	int i=0;

    /* create the message queue */
    mq = mq_open(QUEUE_NAME, O_CREAT | O_RDONLY, 0644, &attr);
    CHECK((mqd_t)-1 != mq);

	FILE *filename = fopen("consumer.txt", "w");

	if (filename == NULL)
	{
		printf("File could nto be opened\n");
		exit(1);
	}

    do {
        ssize_t bytes_read;

        /* receive the message */
        bytes_read = mq_receive(mq, buffer, MAX_SIZE, NULL); 		//message recieved

        CHECK(bytes_read >= 0);		//checks if the bytes_read > 0

        buffer[bytes_read] = '\0';

	printf("%d", i+1);

        printf("Received: %s\n", buffer);		//prints the message

	fprintf(filename, "%d. %s\n", i+1, buffer); 		//the value of buffer is added to the file

i++; 		//counter increment

    } while (i<1000);



    /* cleanup */
    CHECK((mqd_t)-1 != mq_close(mq));
    CHECK((mqd_t)-1 != mq_unlink(QUEUE_NAME));
	fclose(filename);
    return 0;
}
